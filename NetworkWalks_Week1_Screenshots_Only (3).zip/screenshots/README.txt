NetworkWalks Week 1 – Project 1 screenshots

These are the six screenshots supplied by the project owner, organized by the visible VirtualBox configuration screens. Review each image for readability before publishing. The images document settings shown on screen; they do not by themselves prove guest connectivity or successful shared-folder access.
